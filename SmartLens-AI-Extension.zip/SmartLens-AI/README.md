# SmartLens AI - Multimodal Chrome Extension

![Manifest V3](https://img.shields.io/badge/Manifest-V3-blue)
![License](https://img.shields.io/badge/License-MIT-green)

A lightweight Chrome extension demonstrating best practices for multimodal AI applications. Analyze images, explain text with context, and chat with AI—all powered by GPT-4 Vision or Google Gemini.

---

## 🌟 Features

- **🖼️ Image Analysis via Context Menu**: Right-click any image → "Analyze Image with SmartLens" to get captions, object detection, and insights
- **📝 Text Selection Explanation**: Highlight text → Click "Explain" button → Get contextual summaries (with optional nearby image analysis)
- **💬 Chat Interface**: Popup UI with chat history, manual text/image URL input, and full conversation tracking
- **⚙️ API Key Management**: Secure options page to configure OpenAI or Gemini API keys
- **🎨 Clean UI**: Minimal design with vanilla JavaScript, HTML, and CSS—no frameworks required
- **📊 Interaction History**: Stores last 50 interactions with timestamps and type badges

---

## 📁 File Structure

```
SmartLens-AI/
├── manifest.json           # Manifest V3 configuration
├── service_worker.js       # Background script (context menu, API calls)
├── content.js              # Content script (text selection, floating button)
├── popup.html              # Popup UI structure
├── popup.js                # Popup logic and history display
├── options.html            # Options page structure
├── options.js              # Options page logic (API key storage)
├── styles.css              # All styles (popup, content, options)
├── icon16.png              # Extension icon 16x16
├── icon32.png              # Extension icon 32x32
├── icon128.png             # Extension icon 128x128
└── README.md               # This file
```

---

## 🚀 Installation

### Step 1: Download Files
1. Extract the provided ZIP file or clone this repository
2. Ensure all files are in a single folder

### Step 2: Create Icon Files (if not provided)
Create three placeholder PNG icons:
- `icon16.png` (16×16 pixels)
- `icon32.png` (32×32 pixels)
- `icon128.png` (128×128 pixels)

You can use any simple design (e.g., colored square with "SL" text) or generate icons online at [favicon.io](https://favicon.io).

### Step 3: Load Extension in Chrome
1. Open Chrome and navigate to `chrome://extensions/`
2. Enable **Developer mode** (toggle in top-right corner)
3. Click **Load unpacked**
4. Select the `SmartLens-AI` folder
5. The extension icon should appear in your toolbar

---

## ⚙️ Configuration

### Get an API Key

**Option A: OpenAI (GPT-4 Vision)**
1. Visit [platform.openai.com/api-keys](https://platform.openai.com/api-keys)
2. Sign up or log in
3. Create a new API key
4. Copy the key (starts with `sk-...`)

**Option B: Google Gemini Vision Pro**
1. Visit [makersuite.google.com/app/apikey](https://makersuite.google.com/app/apikey)
2. Sign in with Google account
3. Create API key
4. Copy the key

### Configure Extension
1. Click the **SmartLens AI** icon in your toolbar
2. Click **"⚙️ Configure API Key"** at the bottom
3. Select your provider (OpenAI or Gemini)
4. Paste your API key
5. Click **"Save Settings"**
6. Click **"Test Connection"** to verify it works

---

## 📖 Usage Guide

### 1. Image Analysis (Context Menu)
1. Navigate to any webpage with images
2. **Right-click** on an image
3. Select **"Analyze Image with SmartLens"**
4. A result overlay will appear with:
   - Image caption
   - List of detected objects
   - Short insight (1-2 sentences)

### 2. Text Selection Explanation
1. Navigate to any article or webpage with text
2. **Highlight** any text (click and drag to select)
3. A floating **"✨ Explain"** button appears near your cursor
4. Click the button
5. The AI will:
   - Analyze the selected text
   - Check for nearby images (within 200px)
   - Return a 3-bullet contextual summary
6. Result appears in an overlay (auto-closes after 10 seconds)

### 3. Chat from Popup
1. Click the **SmartLens AI** icon in toolbar
2. View your interaction history (last 50 items)
3. Enter text in the textarea
4. *Optional:* Paste an image URL in the second field
5. Click **"Send to AI"**
6. Response appears in chat history
7. Use **"Clear History"** button to reset

---

## 🛠️ API Configuration Details

### OpenAI GPT-4 Vision API

**Endpoint:**
```
https://api.openai.com/v1/chat/completions
```

**Headers:**
```json
{
  "Content-Type": "application/json",
  "Authorization": "Bearer YOUR_API_KEY"
}
```

**Request Body:**
```json
{
  "model": "gpt-4-vision-preview",
  "messages": [
    {
      "role": "user",
      "content": [
        { "type": "text", "text": "Your prompt here" },
        {
          "type": "image_url",
          "image_url": {
            "url": "data:image/jpeg;base64,BASE64_STRING"
          }
        }
      ]
    }
  ],
  "max_tokens": 500
}
```

**Models:**
- `gpt-4-vision-preview` (older)
- `gpt-4-turbo` (recommended)
- `gpt-4o` (latest, best multimodal)

---

### Google Gemini Vision Pro API

**Endpoint:**
```
https://generativelanguage.googleapis.com/v1/models/gemini-pro-vision:generateContent?key=YOUR_API_KEY
```

**Headers:**
```json
{
  "Content-Type": "application/json"
}
```

**Request Body:**
```json
{
  "contents": [
    {
      "parts": [
        { "text": "Your prompt here" },
        {
          "inline_data": {
            "mime_type": "image/jpeg",
            "data": "BASE64_STRING"
          }
        }
      ]
    }
  ]
}
```

---

## 🔧 Customization

### Modify AI Prompts
Edit `service_worker.js` to change how the AI responds:

```javascript
// Line ~78: Image analysis prompt
const prompt = "Analyze this image and provide: 1) A brief caption, 2) List of main objects detected, 3) A short insight (1-2 sentences).";

// Line ~106: Text explanation prompt
let prompt = `Explain the following text and provide a contextual summary in 3 bullet points:\n\n"${text}"`;
```

### Change Nearby Image Detection Range
Edit `content.js` line ~100:

```javascript
let minDistance = 200; // Change to 300 or 500 pixels
```

### Adjust History Size
Edit `service_worker.js` line ~323:

```javascript
if (history.length > 50) { // Change to 100 or 200
  history.shift();
}
```

### Modify Floating Button Auto-Hide
Edit `content.js` line ~41:

```javascript
setTimeout(() => {
  hideFloatingButton();
}, 5000); // Change to 10000 (10 seconds)
```

---

## 🧪 10-Step Quick Test/Demo Script

Use this script to record a comprehensive demo:

### **Test 1: Install Extension**
- Show loading unpacked extension at `chrome://extensions/`
- Point out SmartLens AI icon in toolbar

### **Test 2: Configure API Key**
- Click extension icon → Options
- Show selecting provider and pasting API key
- Demonstrate "Test Connection" → Success message

### **Test 3: Image Context Menu**
- Go to a news site (e.g., CNN, BBC)
- Right-click an image → "Analyze Image with SmartLens"
- Show result overlay with caption, objects, insight

### **Test 4: Text Selection (No Image)**
- Open Wikipedia article
- Highlight a paragraph
- Click "✨ Explain" button
- Show 3-bullet summary

### **Test 5: Text + Nearby Image**
- Find page with text near image
- Highlight text close to image
- Click "Explain"
- Show AI considers both text and image

### **Test 6: Open Popup**
- Click extension icon
- Show chat history with timestamps
- Point out type badges (image_analysis, text_explain, chat)

### **Test 7: Chat with Text Only**
- Type "What is multimodal AI?" in popup
- Click "Send to AI"
- Show result in history

### **Test 8: Chat with Image URL**
- Paste image URL (e.g., from Unsplash)
- Add text "Describe this image"
- Send and show result

### **Test 9: Scroll History**
- Scroll through all interactions
- Show different types and timestamps

### **Test 10: Clear History**
- Click "Clear History"
- Confirm dialog
- Show empty state

---

## 🐛 Troubleshooting

### Context menu not appearing
- **Solution**: Check that `contextMenus` permission is in `manifest.json`
- Reload extension at `chrome://extensions/`

### API errors or "Connection failed"
- **Solution**: Verify API key is correct
- Check endpoint URL in `service_worker.js` (lines 193 and 249)
- Ensure you have API credits/quota remaining

### CORS errors on images
- **Issue**: Some websites block cross-origin image loading
- **Solution**: Use images from sites that allow CORS, or test with your own images

### Service worker inactive
- **Solution**: Go to `chrome://extensions/` → SmartLens AI → Details
- Click "service worker" to open console and check for errors

### Floating button not appearing
- **Solution**: Make sure content script is injected
- Check `manifest.json` has correct `content_scripts` configuration
- Try refreshing the webpage

---

## 🔒 Privacy & Security

- **API Keys**: Stored locally in `chrome.storage.sync` (encrypted by Chrome)
- **No Data Collection**: Extension doesn't send data to any server except your chosen AI provider
- **HTTPS Only**: All API calls use secure HTTPS connections
- **Local History**: Interaction history stored on your device only

---

## 📊 Performance Tips

1. **Large Images**: Base64 conversion may be slow for high-res images
   - Consider adding compression in `getImageAsBase64()` (content.js line ~122)

2. **API Rate Limits**: Avoid rapid successive calls
   - Consider adding debouncing for text selection

3. **Storage Optimization**: History limited to 50 items
   - Increase in `service_worker.js` if needed

---

## 🚀 Development Roadmap

Potential enhancements:
- [ ] Model selection dropdown (GPT-4o vs GPT-4-turbo vs Gemini)
- [ ] Response streaming for real-time feedback
- [ ] Local image file upload in popup
- [ ] Export chat history as JSON/CSV
- [ ] Dark mode theme
- [ ] Custom prompt templates
- [ ] OCR for image text extraction
- [ ] Multi-language support

---

## 📝 License

MIT License - feel free to modify and use for your projects!

---

## 🤝 Contributing

Pull requests welcome! For major changes, please open an issue first.

---

## 📧 Support

For issues or questions:
1. Check the Troubleshooting section above
2. Review Chrome extension logs at `chrome://extensions/`
3. Open an issue on GitHub

---

## 🎓 Learning Resources

- [Chrome Extension MV3 Docs](https://developer.chrome.com/docs/extensions/mv3/)
- [OpenAI Vision API](https://platform.openai.com/docs/guides/vision)
- [Google Gemini API](https://ai.google.dev/docs)
- [Chrome Storage API](https://developer.chrome.com/docs/extensions/reference/api/storage)
- [Context Menus API](https://developer.chrome.com/docs/extensions/reference/api/contextMenus)

---

## ⏱️ Estimated Development Time

- **Setup & File Creation**: 1 hour
- **Core Functionality**: 3-4 hours
- **UI Styling**: 2 hours
- **Testing & Debugging**: 2-3 hours
- **Demo Recording**: 1 hour
- **Total**: 9-11 hours

---

**Built with ❤️ using Manifest V3, Vanilla JS, and Multimodal AI**

*Last Updated: October 31, 2025*
