// options.js - Options page logic for SmartLens AI

document.addEventListener("DOMContentLoaded", () => {
  loadSettings();

  document.getElementById("saveBtn").addEventListener("click", saveSettings);
  document.getElementById("testBtn").addEventListener("click", testConnection);
});

// Load saved settings
function loadSettings() {
  chrome.storage.sync.get(["apiKey", "apiProvider"], (data) => {
    if (data.apiKey) {
      document.getElementById("apiKeyInput").value = data.apiKey;
    }

    if (data.apiProvider) {
      document.getElementById("apiProviderSelect").value = data.apiProvider;
    }
  });
}

// Save settings
function saveSettings() {
  const apiKey = document.getElementById("apiKeyInput").value.trim();
  const apiProvider = document.getElementById("apiProviderSelect").value;

  if (!apiKey) {
    showStatus("Please enter an API key", "error");
    return;
  }

  chrome.storage.sync.set({
    apiKey: apiKey,
    apiProvider: apiProvider
  }, () => {
    showStatus("Settings saved successfully!", "success");
  });
}

// Test API connection
function testConnection() {
  const statusDiv = document.getElementById("statusMessage");
  statusDiv.textContent = "Testing connection...";
  statusDiv.className = "status-message";

  chrome.storage.sync.get(["apiKey", "apiProvider"], (data) => {
    if (!data.apiKey) {
      showStatus("Please save your API key first", "error");
      return;
    }

    // Send a simple test request
    chrome.runtime.sendMessage({
      action: "chatRequest",
      text: "Hello! This is a test message. Please respond with 'OK'.",
      imageUrl: null
    }, (response) => {
      if (response && response.success) {
        showStatus("✅ Connection successful! API is working.", "success");
      } else {
        showStatus("❌ Connection failed: " + (response?.error || "Unknown error"), "error");
      }
    });
  });
}

// Show status message
function showStatus(message, type) {
  const statusDiv = document.getElementById("statusMessage");
  statusDiv.textContent = message;
  statusDiv.className = `status-message ${type}`;

  // Auto-hide success messages after 3 seconds
  if (type === "success") {
    setTimeout(() => {
      statusDiv.textContent = "";
      statusDiv.className = "status-message";
    }, 3000);
  }
}