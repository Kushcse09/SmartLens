// service_worker.js - Background script for SmartLens AI (Manifest V3)
// Handles context menu creation, message routing, and API calls

// Create context menu when extension is installed
chrome.runtime.onInstalled.addListener(() => {
  // Context menu for images: "Analyze Image with SmartLens"
  chrome.contextMenus.create({
    id: "analyzeImage",
    title: "Analyze Image with SmartLens",
    contexts: ["image"]
  });

  console.log("SmartLens AI: Context menus created");
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "analyzeImage") {
    // Get the image URL from context menu
    const imageUrl = info.srcUrl;

    // Convert image URL to base64 and analyze
    fetchImageAsBase64(imageUrl).then(base64 => {
      analyzeImage(base64, tab.id);
    }).catch(err => {
      console.error("Error fetching image:", err);
      notifyTab(tab.id, "Error loading image");
    });
  }
});

// Listen for messages from content script and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Service worker received message:", message.action);

  if (message.action === "analyzeImage") {
    // Analyze image from content script
    analyzeImage(message.imageBase64, sender.tab.id).then(result => {
      sendResponse({ success: true, result });
    }).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true; // Keep channel open for async response
  }

  if (message.action === "explainText") {
    // Explain selected text (with optional nearby image)
    explainText(message.text, message.imageBase64, sender.tab.id).then(result => {
      sendResponse({ success: true, result });
    }).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true;
  }

  if (message.action === "chatRequest") {
    // Handle chat request from popup
    handleChatRequest(message.text, message.imageUrl).then(result => {
      sendResponse({ success: true, result });
    }).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true;
  }

  if (message.action === "getHistory") {
    // Return chat history to popup
    chrome.storage.local.get(["chatHistory"], (data) => {
      sendResponse({ history: data.chatHistory || [] });
    });
    return true;
  }

  if (message.action === "clearHistory") {
    // Clear chat history
    chrome.storage.local.set({ chatHistory: [] }, () => {
      sendResponse({ success: true });
    });
    return true;
  }
});

// ===== CORE AI FUNCTIONS =====

// Analyze image and return caption, objects, insight
async function analyzeImage(base64Image, tabId) {
  const prompt = "Analyze this image and provide: 1) A brief caption, 2) List of main objects detected, 3) A short insight (1-2 sentences).";

  const result = await callMultimodalAI({
    text: prompt,
    imageBase64: base64Image
  });

  // Save to history
  saveToHistory("image_analysis", { prompt, result });

  // Notify content script with result
  if (tabId) {
    chrome.tabs.sendMessage(tabId, {
      action: "showResult",
      result: result,
      type: "image"
    });
  }

  return result;
}

// Explain selected text with optional nearby image
async function explainText(text, imageBase64, tabId) {
  let prompt = `Explain the following text and provide a contextual summary in 3 bullet points:\n\n"${text}"`;

  if (imageBase64) {
    prompt += "\n\n(Also consider the nearby image in your explanation)";
  }

  const result = await callMultimodalAI({
    text: prompt,
    imageBase64: imageBase64
  });

  // Save to history
  saveToHistory("text_explain", { text, result });

  // Notify content script
  if (tabId) {
    chrome.tabs.sendMessage(tabId, {
      action: "showResult",
      result: result,
      type: "text"
    });
  }

  return result;
}

// Handle chat request from popup
async function handleChatRequest(text, imageUrl) {
  let imageBase64 = null;

  // If image URL provided, fetch as base64
  if (imageUrl) {
    imageBase64 = await fetchImageAsBase64(imageUrl);
  }

  const result = await callMultimodalAI({
    text: text,
    imageBase64: imageBase64
  });

  // Save to history
  saveToHistory("chat", { text, imageUrl, result });

  return result;
}

// ===== MULTIMODAL AI API CALL =====

/**
 * Call multimodal AI endpoint with text and/or image
 * REPLACE THIS FUNCTION WITH YOUR ACTUAL API ENDPOINT
 * 
 * Supports both OpenAI GPT-4 Vision and Google Gemini formats
 * 
 * @param {Object} params - { text: string, imageBase64: string }
 * @returns {Promise<string>} - AI response text
 */
async function callMultimodalAI({ text, imageBase64 }) {
  // Get API key from storage
  const { apiKey, apiProvider } = await chrome.storage.sync.get(["apiKey", "apiProvider"]);

  if (!apiKey) {
    throw new Error("API key not configured. Please set it in Options.");
  }

  // Default to OpenAI if not specified
  const provider = apiProvider || "openai";

  if (provider === "openai") {
    return await callOpenAI(text, imageBase64, apiKey);
  } else if (provider === "gemini") {
    return await callGemini(text, imageBase64, apiKey);
  } else {
    throw new Error("Unknown API provider");
  }
}

// OpenAI GPT-4 Vision API format
async function callOpenAI(text, imageBase64, apiKey) {
  const messages = [
    {
      role: "user",
      content: []
    }
  ];

  // Add text
  if (text) {
    messages[0].content.push({
      type: "text",
      text: text
    });
  }

  // Add image if provided
  if (imageBase64) {
    messages[0].content.push({
      type: "image_url",
      image_url: {
        url: `data:image/jpeg;base64,${imageBase64}`
      }
    });
  }

  // REPLACE WITH YOUR OPENAI ENDPOINT
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: "gpt-4-vision-preview", // Use gpt-4-turbo or gpt-4o for better vision
      messages: messages,
      max_tokens: 500
    })
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`OpenAI API error: ${error}`);
  }

  const data = await response.json();
  return data.choices[0].message.content;
}

// Google Gemini Vision Pro API format
async function callGemini(text, imageBase64, apiKey) {
  const parts = [];

  // Add text
  if (text) {
    parts.push({ text: text });
  }

  // Add image if provided
  if (imageBase64) {
    parts.push({
      inline_data: {
        mime_type: "image/jpeg",
        data: imageBase64
      }
    });
  }

  // REPLACE WITH YOUR GEMINI ENDPOINT
  const response = await fetch(`https://generativelanguage.googleapis.com/v1/models/gemini-pro-vision:generateContent?key=${apiKey}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      contents: [{
        parts: parts
      }]
    })
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Gemini API error: ${error}`);
  }

  const data = await response.json();
  return data.candidates[0].content.parts[0].text;
}

// ===== HELPER FUNCTIONS =====

// Fetch image from URL and convert to base64
async function fetchImageAsBase64(imageUrl) {
  const response = await fetch(imageUrl);
  const blob = await response.blob();

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      // Remove data:image/...;base64, prefix
      const base64 = reader.result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// Save interaction to history
function saveToHistory(type, data) {
  chrome.storage.local.get(["chatHistory"], (result) => {
    const history = result.chatHistory || [];
    history.push({
      type: type,
      timestamp: new Date().toISOString(),
      data: data
    });

    // Keep only last 50 items
    if (history.length > 50) {
      history.shift();
    }

    chrome.storage.local.set({ chatHistory: history });
  });
}

// Notify tab with message
function notifyTab(tabId, message) {
  chrome.tabs.sendMessage(tabId, {
    action: "showNotification",
    message: message
  });
}