// popup.js - Popup UI logic for SmartLens AI

document.addEventListener("DOMContentLoaded", () => {
  loadChatHistory();

  // Event listeners
  document.getElementById("sendChatBtn").addEventListener("click", handleSendChat);
  document.getElementById("clearHistoryBtn").addEventListener("click", handleClearHistory);
  document.getElementById("openOptionsLink").addEventListener("click", openOptions);

  // Allow Enter key to send (Shift+Enter for new line)
  document.getElementById("chatTextInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendChat();
    }
  });
});

// Load and display chat history
function loadChatHistory() {
  chrome.runtime.sendMessage({ action: "getHistory" }, (response) => {
    const historyContainer = document.getElementById("chatHistory");

    if (!response.history || response.history.length === 0) {
      historyContainer.innerHTML = `
        <div class="empty-state">
          <p>No interactions yet. Try:</p>
          <ul>
            <li>Right-click an image → "Analyze Image"</li>
            <li>Select text → Click "Explain"</li>
            <li>Use the form below to chat</li>
          </ul>
        </div>
      `;
      return;
    }

    // Build history HTML
    historyContainer.innerHTML = "";

    response.history.forEach((item, index) => {
      const itemDiv = document.createElement("div");
      itemDiv.className = "history-item";

      // Format timestamp
      const time = new Date(item.timestamp).toLocaleTimeString();

      // Type badge
      const typeBadge = document.createElement("span");
      typeBadge.className = "type-badge";
      typeBadge.textContent = item.type.replace("_", " ");

      // Content
      const content = document.createElement("div");
      content.className = "history-content";

      if (item.type === "image_analysis") {
        content.innerHTML = `
          <div class="history-label">Image Analysis</div>
          <div class="history-result">${item.data.result}</div>
        `;
      } else if (item.type === "text_explain") {
        content.innerHTML = `
          <div class="history-label">Text: "${truncate(item.data.text, 50)}"</div>
          <div class="history-result">${item.data.result}</div>
        `;
      } else if (item.type === "chat") {
        content.innerHTML = `
          <div class="history-label">You: ${truncate(item.data.text, 50)}</div>
          ${item.data.imageUrl ? `<div class="history-image-url">🖼️ ${truncate(item.data.imageUrl, 40)}</div>` : ""}
          <div class="history-result">${item.data.result}</div>
        `;
      }

      // Time
      const timeDiv = document.createElement("div");
      timeDiv.className = "history-time";
      timeDiv.textContent = time;

      itemDiv.appendChild(typeBadge);
      itemDiv.appendChild(content);
      itemDiv.appendChild(timeDiv);

      historyContainer.appendChild(itemDiv);
    });

    // Scroll to bottom
    historyContainer.scrollTop = historyContainer.scrollHeight;
  });
}

// Handle send chat button
function handleSendChat() {
  const textInput = document.getElementById("chatTextInput");
  const imageUrlInput = document.getElementById("chatImageUrl");
  const sendBtn = document.getElementById("sendChatBtn");

  const text = textInput.value.trim();
  const imageUrl = imageUrlInput.value.trim();

  if (!text && !imageUrl) {
    alert("Please enter text or an image URL");
    return;
  }

  // Show loading state
  sendBtn.textContent = "Sending...";
  sendBtn.disabled = true;

  // Send to service worker
  chrome.runtime.sendMessage({
    action: "chatRequest",
    text: text,
    imageUrl: imageUrl
  }, (response) => {
    // Reset button
    sendBtn.textContent = "Send to AI";
    sendBtn.disabled = false;

    if (response && response.success) {
      // Clear inputs
      textInput.value = "";
      imageUrlInput.value = "";

      // Reload history
      loadChatHistory();
    } else {
      alert("Error: " + (response?.error || "Unknown error"));
    }
  });
}

// Handle clear history
function handleClearHistory() {
  if (!confirm("Clear all chat history?")) {
    return;
  }

  chrome.runtime.sendMessage({ action: "clearHistory" }, (response) => {
    if (response && response.success) {
      loadChatHistory();
    }
  });
}

// Open options page
function openOptions(e) {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
}

// Utility: Truncate text
function truncate(text, maxLength) {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + "...";
}