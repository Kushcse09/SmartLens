// content.js - Content script for SmartLens AI
// Detects text selections, injects floating "Explain" button, captures nearby images

let floatingButton = null;
let selectedText = "";
let selectionRange = null;

// Listen for text selection
document.addEventListener("mouseup", handleTextSelection);
document.addEventListener("selectionchange", handleSelectionChange);

// Handle text selection
function handleTextSelection(event) {
  const selection = window.getSelection();
  selectedText = selection.toString().trim();

  if (selectedText.length > 0) {
    selectionRange = selection.getRangeAt(0);
    showFloatingButton(event.pageX, event.pageY);
  } else {
    hideFloatingButton();
  }
}

// Handle selection change (keyboard selection)
function handleSelectionChange() {
  const selection = window.getSelection();
  selectedText = selection.toString().trim();

  if (selectedText.length === 0) {
    hideFloatingButton();
  }
}

// Show floating "Explain" button near selection
function showFloatingButton(x, y) {
  // Remove existing button if any
  hideFloatingButton();

  // Create floating button
  floatingButton = document.createElement("div");
  floatingButton.id = "smartlens-explain-btn";
  floatingButton.className = "smartlens-floating-btn";
  floatingButton.textContent = "✨ Explain";
  floatingButton.style.left = `${x + 10}px`;
  floatingButton.style.top = `${y + 10}px`;

  // Add click handler
  floatingButton.addEventListener("click", handleExplainClick);

  document.body.appendChild(floatingButton);

  // Auto-hide after 5 seconds if not clicked
  setTimeout(() => {
    hideFloatingButton();
  }, 5000);
}

// Hide floating button
function hideFloatingButton() {
  if (floatingButton) {
    floatingButton.remove();
    floatingButton = null;
  }
}

// Handle "Explain" button click
async function handleExplainClick(event) {
  event.stopPropagation();

  // Show loading state
  floatingButton.textContent = "⏳ Loading...";
  floatingButton.style.pointerEvents = "none";

  // Find nearby image (within 200px of selection)
  const nearbyImage = findNearbyImage();
  let imageBase64 = null;

  if (nearbyImage) {
    try {
      imageBase64 = await getImageAsBase64(nearbyImage);
    } catch (err) {
      console.warn("Could not capture nearby image:", err);
    }
  }

  // Send to service worker for analysis
  chrome.runtime.sendMessage({
    action: "explainText",
    text: selectedText,
    imageBase64: imageBase64
  }, (response) => {
    hideFloatingButton();

    if (response && response.success) {
      showResultOverlay(response.result, "text");
    } else {
      showResultOverlay("Error: " + (response?.error || "Unknown error"), "error");
    }
  });
}

// Find nearby image within 200px of selection
function findNearbyImage() {
  if (!selectionRange) return null;

  const rect = selectionRange.getBoundingClientRect();
  const centerX = rect.left + rect.width / 2;
  const centerY = rect.top + rect.height / 2;

  // Find all images on page
  const images = document.querySelectorAll("img");
  let closestImage = null;
  let minDistance = 200; // pixels

  images.forEach(img => {
    const imgRect = img.getBoundingClientRect();
    const imgCenterX = imgRect.left + imgRect.width / 2;
    const imgCenterY = imgRect.top + imgRect.height / 2;

    // Calculate distance
    const distance = Math.sqrt(
      Math.pow(centerX - imgCenterX, 2) + 
      Math.pow(centerY - imgCenterY, 2)
    );

    if (distance < minDistance) {
      minDistance = distance;
      closestImage = img;
    }
  });

  return closestImage;
}

// Convert image element to base64
async function getImageAsBase64(imgElement) {
  return new Promise((resolve, reject) => {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");

    canvas.width = imgElement.naturalWidth || imgElement.width;
    canvas.height = imgElement.naturalHeight || imgElement.height;

    // Handle CORS
    const img = new Image();
    img.crossOrigin = "anonymous";

    img.onload = () => {
      ctx.drawImage(img, 0, 0);
      try {
        const dataUrl = canvas.toDataURL("image/jpeg", 0.8);
        const base64 = dataUrl.split(',')[1];
        resolve(base64);
      } catch (err) {
        reject(err);
      }
    };

    img.onerror = reject;
    img.src = imgElement.src;
  });
}

// Show result overlay
function showResultOverlay(result, type) {
  // Remove existing overlay
  const existingOverlay = document.getElementById("smartlens-result-overlay");
  if (existingOverlay) {
    existingOverlay.remove();
  }

  // Create overlay
  const overlay = document.createElement("div");
  overlay.id = "smartlens-result-overlay";
  overlay.className = "smartlens-overlay";

  const content = document.createElement("div");
  content.className = "smartlens-overlay-content";

  // Add close button
  const closeBtn = document.createElement("button");
  closeBtn.className = "smartlens-close-btn";
  closeBtn.textContent = "×";
  closeBtn.onclick = () => overlay.remove();

  // Add result text
  const resultText = document.createElement("div");
  resultText.className = "smartlens-result-text";
  resultText.textContent = result;

  content.appendChild(closeBtn);
  content.appendChild(resultText);
  overlay.appendChild(content);

  document.body.appendChild(overlay);

  // Auto-remove after 10 seconds
  setTimeout(() => {
    if (overlay.parentNode) {
      overlay.remove();
    }
  }, 10000);
}

// Listen for messages from service worker
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "showResult") {
    showResultOverlay(message.result, message.type);
  }

  if (message.action === "showNotification") {
    showResultOverlay(message.message, "notification");
  }
});

// Clean up on page unload
window.addEventListener("beforeunload", () => {
  hideFloatingButton();
});